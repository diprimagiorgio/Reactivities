//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	truclient_step("1", "Navigate to 'https://tutorial-reacti....herokuapp.com/'", "snapshot=Action_1.inf");
	truclient_step("3", "Click on Register! button", "snapshot=Action_3.inf");
	truclient_step("5", "Register", "snapshot=Action_5.inf");
	{
		truclient_step("5.1", "Click on Display Name textbox", "snapshot=Action_5.1.inf");
		truclient_step("5.2", "Type test in Display Name textbox", "snapshot=Action_5.2.inf");
		truclient_step("5.3", "Type usernames in Username textbox", "snapshot=Action_5.3.inf");
		truclient_step("5.4", "Type usernames in Email textbox", "snapshot=Action_5.4.inf");
		truclient_step("5.5", "Type ****** in Password passwordbox", "snapshot=Action_5.5.inf");
		truclient_step("5.7", "Click on Register button", "snapshot=Action_5.7.inf");
	}
	truclient_step("7", "Click on test", "snapshot=Action_7.inf");
	truclient_step("9", "Click on Logout", "snapshot=Action_9.inf");

	return 0;
}
